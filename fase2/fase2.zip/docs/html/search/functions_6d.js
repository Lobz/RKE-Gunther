var searchData=
[
  ['manual',['manual',['../gunther_8h.html#af3231d0d69b075fdf6a3fffc4e05f50b',1,'manual(SDL_Surface *screen, int section):&#160;menu.c'],['../menu_8c.html#a4f64a22b2d93a0825625d69dec8b5524',1,'manual(SDL_Surface *screen, int mode):&#160;menu.c']]]
];
