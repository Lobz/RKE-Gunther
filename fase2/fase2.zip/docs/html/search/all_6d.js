var searchData=
[
  ['main_2ec',['main.c',['../main_8c.html',1,'']]],
  ['manual',['manual',['../gunther_8h.html#af3231d0d69b075fdf6a3fffc4e05f50b',1,'manual(SDL_Surface *screen, int section):&#160;menu.c'],['../menu_8c.html#a4f64a22b2d93a0825625d69dec8b5524',1,'manual(SDL_Surface *screen, int mode):&#160;menu.c']]],
  ['menu_2ec',['menu.c',['../menu_8c.html',1,'']]]
];
