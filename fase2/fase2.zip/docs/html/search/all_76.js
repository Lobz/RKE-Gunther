var searchData=
[
  ['vetor',['vetor',['../rketypes_8h.html#a27896866572b2a12760a22ea2654ed47',1,'rketypes.h']]]
];
