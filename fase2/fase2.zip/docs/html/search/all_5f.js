var searchData=
[
  ['_5fjogador',['_jogador',['../struct__jogador.html',1,'']]],
  ['_5fladrilho',['_ladrilho',['../struct__ladrilho.html',1,'']]],
  ['_5fobjeto',['_objeto',['../struct__objeto.html',1,'']]],
  ['_5ftabuleiro',['_tabuleiro',['../struct__tabuleiro.html',1,'']]]
];
