var searchData=
[
  ['gunther_5fmenu',['gunther_menu',['../gunther_8h.html#acf814435dd822e55f2537b49cc6c1505',1,'gunther_menu(SDL_Surface *tela):&#160;menu.c'],['../menu_8c.html#acf814435dd822e55f2537b49cc6c1505',1,'gunther_menu(SDL_Surface *tela):&#160;menu.c']]]
];
