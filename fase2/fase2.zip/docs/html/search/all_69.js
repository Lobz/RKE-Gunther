var searchData=
[
  ['inicio',['inicio',['../gunther_8h.html#ac241ff40fd02c916d3dd71a0f150d3f6',1,'inicio(SDL_Surface *screen):&#160;menu.c'],['../menu_8c.html#ac241ff40fd02c916d3dd71a0f150d3f6',1,'inicio(SDL_Surface *screen):&#160;menu.c']]]
];
